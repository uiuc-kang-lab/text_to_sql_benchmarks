import json
import copy
from utils.util import get_all_schema,extract_tables_and_columns





def recall_get_table(json_file='schema_gpt.json'):
    # 存储每个gold sql中，涉及的所有 table_name.column_name
    stats = []
    stats_1 = []
    db_schema_copy = copy.deepcopy(get_all_schema())

    with open('/Users/mac/Desktop/spider/data/test.json', 'r') as f:
        dev_set = json.load(f)

    # schema linking
    ground_truths = []
    for example in dev_set:
        ground_truth = []
        ans = extract_tables_and_columns(example['query'])
        stats_1.append(len(ans['table']))  # 一个sql语句中涉及的表的数量
        for table in ans['table']:
            for column in ans['column']:
                schema = table + '.' + column
                list_db = [item.lower() for item in db_schema_copy[example['db_id']]]
                if schema.lower() in list_db:
                    ground_truth.append(schema)
        stats.append(len(ground_truth))
        ground_truths.append(ground_truth)

    ### schema linking_pred
    with open(json_file, 'r') as f:
        clms = json.load(f)
    pred_truths = []
    for i in range(len(clms)):
        clm = clms[i]
        pred_truth = []
        columns = clm['columns']
        db_name = dev_set[i]['db_id']
        for column in columns:
            schema = column.replace('`', '')
            if schema.lower() in [item.lower() for item in db_schema_copy[db_name]]:
                pred_truth.append(schema)
        stats.append(len(pred_truth))
        pred_truths.append(pred_truth)

    num = 0
    for ground_truth, pred_truth in zip(ground_truths, pred_truths):
        x1 = set(item.lower() for item in ground_truth)
        x2 = set(item.lower() for item in pred_truth)
        if x1.issubset(x2):
            num += 1

    print(num / len(ground_truths))


recall_get_table(json_file='schema.json')
