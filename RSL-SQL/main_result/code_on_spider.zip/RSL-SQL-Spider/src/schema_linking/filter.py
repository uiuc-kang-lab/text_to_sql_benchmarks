import os
import sqlite3
from pprint import pprint
import sqlglot
import json
import copy


def get_tables_and_columns(sqlite_db_path):
    with sqlite3.connect(sqlite_db_path) as conn:
        cursor = conn.cursor()
        tables = cursor.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()

        return [
            f"{_table[0]}.{_column[1]}"
            for _table in tables
            for _column in cursor.execute(f"PRAGMA table_info('{_table[0]}');").fetchall()
        ]



def return_db_schema():
    # 读取所有数据库
    db_base_path = '/Users/mac/Desktop/spider/test_database'
    db_schema = {}
    for db_name in os.listdir(db_base_path):
        db_path = os.path.join(db_base_path, db_name, db_name + '.sqlite')
        if os.path.exists(db_path):
            db_schema[db_name] = get_tables_and_columns(db_path)
    return db_schema

def extract_tables_and_columns(sql_query):
    parsed_query = sqlglot.parse_one(sql_query, read="sqlite")
    table_names = parsed_query.find_all(sqlglot.exp.Table)
    column_names = parsed_query.find_all(sqlglot.exp.Column)
    return {
        'table': {_table.name for _table in table_names},
        'column': {_column.alias_or_name for _column in column_names}
    }

# 存储每个gold sql中，涉及的所有 table_name.column_name
stats = []
stats_1 = []
db_schema_copy = copy.deepcopy(return_db_schema())



with open('/Users/mac/Desktop/spider/data/test.json', 'r') as f:
    dev_set = json.load(f)

with open('schema.json','r') as f:
    informations = json.load(f)

preds=[]
for i in range(len(informations)):

    pred=[]

    information = informations[i]
    db = dev_set[i]['db_id']

    db_schema = db_schema_copy[db]


    columns = information['columns']
    columns = [obj.replace('`','') for obj in columns]

    for obj in db_schema:
        if obj.lower() in columns and obj.lower() not in pred:
            pred.append(obj)

    preds.append(pred)


tables=[]
for i in range(len(preds)):
    table=[]
    preds[i] = [item for item in preds[i]]
    for item in preds[i]:
        t = item.split('.')[0]
        if t not in table:
            table.append(t)
    tables.append(table)

answers = []
for i in range(len(preds)):
    answer = {}
    answer['tables'] = tables[i]
    answer['columns'] = preds[i]
    answers.append(answer)

with open('schema.json', 'w') as f:
    json.dump(answers, f, indent=4, ensure_ascii=False)

print()



print()