import json

with open('sql.json', 'r') as f:
    clms = json.load(f)

with open('LLM.json', 'r') as f:
    dev_set = json.load(f)

an =[]

for clm,dev in zip(clms,dev_set):

    dev_tables = [obj.lower() for obj in dev['tables']]
    dev_columns = [obj.lower() for obj in dev['columns']]
    clm_tables = [obj.lower() for obj in clm['tables']]
    clm_columns = [obj.lower() for obj in clm['columns']]


    tables = dev_tables + clm_tables
    columns = dev_columns + clm_columns

    tables = list(set(tables))
    columns = list(set(columns))

    x = {}
    x['tables'] = tables
    x['columns'] = columns
    an.append(x)

with open('schema.json', 'w') as f:
    json.dump(an, f, indent=4, ensure_ascii=False)





