dev_databases_path = '/Users/mac/Desktop/RSL-SQL-Spider/test_database'
dev_json_path = '/Users/mac/Desktop/RSL-SQL-Spider/data/test.json'

model='..' #gpt-4o or deepseek-coder
api = '..'
base_url = '..'