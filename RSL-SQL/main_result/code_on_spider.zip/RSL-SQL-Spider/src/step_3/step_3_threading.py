
import os
import threading
from step_3_main import main
from utils.util import split_json,merge_sqltxt,merge_json,split_txt

def round():
    split_json('information/ppl_dev.json','split_ppl/ppl')
    split_txt('../step_1/step_1_sql.txt', 'split_sql1/sql')
    split_txt('../step_2/step_2_sql.txt', 'split_sql2/sql')

    ppl_files=['ppl_file1.json','ppl_file2.json','ppl_file3.json','ppl_file4.json']
    output_files=['output_file1.txt','output_file2.txt','output_file3.txt','output_file4.txt']
    sql1_files = ['sql_file1.txt','sql_file2.txt','sql_file3.txt','sql_file4.txt']
    sql2_files = ['sql_file1.txt','sql_file2.txt','sql_file3.txt','sql_file4.txt']
    threads = []
    for i in range(4):
        t = threading.Thread(target=main, args=( f'split_ppl/{ppl_files[i]}', f'split_output/{output_files[i]}',f'split_sql1/{sql1_files[i]}',f'split_sql2/{sql2_files[i]}' ))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print('All threads are done!')



    merge_sqltxt(output_files,'step_3_sql.txt')
    print('All txt files are merged!')



round()

