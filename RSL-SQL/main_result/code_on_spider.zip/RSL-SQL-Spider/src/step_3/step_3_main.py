from llm.select_gpt import DeepSeek as thought_gpt
import json
from tqdm import tqdm
from utils.util import execute_sql,simple_throw_row_data

def main(ppl_file, output_file,sql_file1,sql_file2):
    thought_gpt_model = thought_gpt()

    # 1.加载prompt信息 从0开始
    with open(ppl_file, 'r') as f:
        ppls = json.load(f)

    with open(sql_file1, 'r') as f:
        sqls1s = f.readlines()


    with open(sql_file2, 'r') as f:

        sqls2s = f.readlines()

    answers = []

    for i in tqdm(range(len(ppls))):
        ppl = ppls[i]
        db = ppl['db']
        question = ppl['question'].strip()
        simple_ddl = ppl['simplified_ddl'].strip()
        ddl_data = ppl['ddl_data'].strip()
        foreign_key = ppl['foreign_key'].strip()
        # evidence = ppl['evidence'].strip()
        example = ppl['example']

        tables = ppl['tables']
        columns = ppl['columns']


        # 简化ddl
        table_list = {}
        simple_ddl_simple = "#\n# "
        for table in tables:
            simple_ddl_simple += table + "("
            column_list = []
            for column in columns:
                _table = column.split(".")[0].strip()
                if _table == table:
                    column = column.split(".")[1].strip()
                    column_list.append(column)
                    simple_ddl_simple += column + ","
            table_list[table] = column_list
            simple_ddl_simple = simple_ddl_simple[:-1] + ")\n# "
        simple_ddl = simple_ddl_simple.strip()

        # 简化data
        data_ddl = simple_throw_row_data(db, tables, table_list)
        ddl_data = "#\n" + data_ddl.strip() + "\n# "

        # 简化foreign_key
        temp = "#\n"
        for line in foreign_key.split("\n"):
            try:
                table1 = line.split("# ")[1].split("(")[0].strip()
                table2 = line.split("references ")[1].split("(")[0].strip()
                if table1.lower() in tables and table2.lower() in tables:
                    temp += line + "\n"
            except:
                continue
        foreign_key = temp.strip() + "\n# "




        table_info = '### Sqlite SQL tables, with their properties:\n'
        table_info += simple_ddl + '\n' + '### Here are some data information about database references.\n' + ddl_data + '\n### Foreign key information of Sqlite SQL tables, used for table joins:\n' + foreign_key

        table_info = example.strip() + '\n\n' + "### Answer the question by sqlite SQL query only and with no explanation. You must minimize SQL execution time while ensuring correctness.\n" + table_info.strip() + '\n\n'  + "### Question: " + question

        sql1 = sqls1s[i].strip()
        sql2 = sqls2s[i].strip()

        r1,c1,re1 = execute_sql(sql1, db)
        r2,c2,re2 = execute_sql(sql2, db)

        candidate_sql = f"### sql1: {sql1} \n### result1: {re1} \n### sql2: {sql2} \n### result2: {re2}"

        # 3.4. thought_gpt
        answer = thought_gpt_model(table_info,candidate_sql)
        try:
            answer = json.loads(answer)
        except Exception as e:
            print(e)
            answer = answer.replace("\\", "\\\\")
            answer = json.loads(answer)
        answer = answer['sql'].replace('\n', ' ')
        answers.append(answer)

        with open(output_file, 'w', encoding='utf-8') as file:
            for sql in answers:
                file.write(str(sql) + '\n')



# main('information/ppl_dev.json',  'step_3_sql.txt','../step_1/step_1_sql.txt','../step_2/step_2_sql.txt')


# extract_sql('output.json', 'output.sql')



