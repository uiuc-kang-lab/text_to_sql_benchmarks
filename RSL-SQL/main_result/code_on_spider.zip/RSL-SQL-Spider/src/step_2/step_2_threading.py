
import os
import threading
from step_2_main import main
from utils.util import split_json,merge_sqltxt,merge_json

def round():
    split_json('information/ppl_dev.json','split_ppl/ppl')

    ppl_files=['ppl_file1.json','ppl_file2.json','ppl_file3.json','ppl_file4.json']
    output_files=['output_file1.txt','output_file2.txt','output_file3.txt','output_file4.txt']
    information_files=['information_file1.json','information_file2.json','information_file3.json','information_file4.json']
    threads = []
    for i in range(4):
        t = threading.Thread(target=main, args=( f'split_ppl/{ppl_files[i]}', f'split_output/{output_files[i]}',f'split_information/{information_files[i]}' ))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print('All threads are done!')

    # please merge the output files ---> aug.json
    # information_files=['information_file1.json','information_file2.json','information_file3.json','information_file4.json']

    merge_sqltxt(output_files,'step_2_sql.txt')
    print('All txt files are merged!')



round()

