import openai
import json
from src.configs.config import api, base_url


sys_message = '''
你是一个智能体，负责根据用户问题识别其中的条件，并明确这些条件之间的关系。你的主要任务是：

1. 理解用户问题：解析用户的问题，提取出问题中的所有条件。
2. 识别条件：
   - 从用户问题中识别出具体的条件。例如，“年龄大于30岁”或“收入超过5000”。
3. 生成输出：
   - 列出所有识别出的条件。

### 输入:
- 用户问题：自然语言形式的查询或问题。

### 输出:
- 条件列表：从用户问题中提取出的所有条件。

### 操作步骤:
1. 解析用户问题：使用自然语言处理技术，提取问题中的条件和关系。
2. 识别条件：根据解析结果，识别出用户问题中的所有条件。
3. 生成结果：形成条件列表和关系列表，返回给用户。
4. 以json格式返回，格式为 {"conditions": ["条件1", "条件2", ...]}。

### 注意事项:
- 确保正确提取和理解用户问题中的所有条件。
- 如果用户问题包含复杂的条件或多个关系，请根据上下文做出合理的判断。
'''


class DeepSeek:
    def __init__(self):
        self.client = openai.OpenAI(api_key=api, base_url=base_url)

    def __call__(self, prompt):

        num = 0
        flag = True
        while num<3 and flag:
            try:
                response = self.client.chat.completions.create(
                    model="deepseek-coder",
                    messages=[
                        {"role": "system", "content": sys_message},
                        {"role": "user", "content": prompt},
                    ],
                    response_format={"type": "json_object"},
                    temperature=0,
                    stream=False,

                )
            except Exception as e:
                print(e)
                continue
            try:
                json.loads(response.choices[0].message.content)
                flag = False
            except:
                flag = True
                num += 1

        return response.choices[0].message.content



