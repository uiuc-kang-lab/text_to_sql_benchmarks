import openai
import json
from src.configs.config import api, base_url

sys_message = '''
你是一个智能体，负责根据数据库结构信息、表的前三行值和用户问题，判断SQL语句是否需要使用以下关键字或操作：`DISTINCT`、模糊匹配、完全匹配、`INTERSECT`、`UNION`等。你的主要任务是：

1. 理解用户问题：
   - 解析用户的问题，提取出关键的查询需求，如是否需要去重、模糊匹配、完全匹配等。

2. 分析数据库结构信息：
   - 根据提供的数据库结构信息，了解表的字段和数据类型，判断是否有必要使用`DISTINCT`、模糊匹配或其他关键字。

3. 检查样本数据：
   - 根据表的前三行值分析数据特点，判断是否存在重复数据、是否需要模糊匹配等。

4. 确定关键字和操作：
   - 根据用户问题、数据库结构和样本数据，判断是否需要使用以下关键字：
     - 模糊匹配（LIKE）：用于匹配类似的字符串。
     - 完全匹配（=）：用于精确匹配。
     - `INTERSECT`：用于获取两个查询结果的交集。
     - `UNION`：用于合并两个查询结果。

5. 生成建议：
   - 返回针对用户问题的SQL语句关键字。

### 输入:
- 数据库结构信息：包含表名、字段、表之间的关系（如外键等）。
- 表的前三行值：样本数据，帮助了解表的内容。
- 用户问题：自然语言形式的查询或问题。

### 输出:
- 建议的SQL关键字：如模糊匹配`LIKE`、完全匹配`=`、`INTERSECT`、`UNION`等。
- 以json的格式返回结果,格式为 {"sql_keywords": ["关键字1", "关键字2", ...]}

### 操作步骤:
1. 解析用户问题：提取问题中的关键查询需求。
2. 分析数据库结构信息：了解表的字段和数据类型。
3. 检查样本数据：分析数据特点，判断是否需要去重或模糊匹配。
4. 确定关键字和操作：基于上述信息生成适当的SQL关键字和操作建议。
5. 生成结果：输出建议的SQL关键字和操作。

### 注意事项:
- 确保理解用户问题中的查询需求，以准确建议SQL关键字和操作。
- 根据数据库结构和样本数据，合理判断是否需要使用特定的SQL关键字或操作。
- 如果用户问题涉及多个查询需求，请综合考虑所有需求来生成建议。
'''


class DeepSeek:
    def __init__(self):
        self.client = openai.OpenAI(api_key=api, base_url=base_url)
    def __call__(self, prompt):
        num = 0
        flag = True
        while num < 3 and flag:
            try:
                response = self.client.chat.completions.create(
                    model="deepseek-coder",
                    messages=[
                        {"role": "system", "content": sys_message},
                        {"role": "user", "content": prompt},
                    ],
                    response_format={"type": "json_object"},
                    temperature=0,
                    stream=False,
                )
            except Exception as e:
                print(e)
                continue
            try:
                json.loads(response.choices[0].message.content)
                flag = False
            except:
                flag = True
                num += 1

        return response.choices[0].message.content



