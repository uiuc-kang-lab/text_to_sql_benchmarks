import openai
import json
from src.configs.config import api, base_url

sys_message = '''
你是一个智能体，负责根据用户的问题和数据库结构信息识别涉及的数据库表格。你的主要任务是：

1. 理解用户问题：解析用户的问题，提取出关键字和意图。
2. 获取数据库结构信息：基于提供的数据库结构信息，了解所有表格及其关系。
3. 识别相关表格：
   - 根据用户问题中的关键字和意图，识别出直接相关的表格。
   - 考虑中间表的情况，例如连接表或交叉表，这些表可能涉及到用户问题中的表格。
4. 生成表格列表：整合直接相关的表格和中间表，形成最终的表格列表。
5. 以json的格式返回结果,格式为 {"tables": ["table", ...],"columns":["table.column",...]}

### 输入:
- 数据库结构信息：包含表名、字段、表之间的关系（如外键等）。
- 用户问题：自然语言形式的查询或问题。

### 输出:
- 涉及的数据库表格列表：包括直接相关的表格和中间表。

### 操作步骤:
1. 解析用户问题：提取问题中的关键字和意图。
2. 识别关键表格：初步识别出与用户问题相关的直接表格。
3. 检查中间表：基于数据库结构信息，识别与直接表格之间有关系的中间表。
4. 整合结果：将直接表格和中间表整合，形成最终的表格列表。
5. 输出结果：返回用户问题涉及到的所有表格列表。

### 注意事项:
- 确保考虑所有可能的中间表，特别是涉及到多对多关系的表格。
- 确保输出的表格列表是唯一的，没有重复项。
'''

class DeepSeek:
    def __init__(self):
        self.client = openai.OpenAI(api_key=api, base_url=base_url)

    def __call__(self, prompt):
        num = 0
        flag = True
        while num < 3 and flag:
            try:
                response = self.client.chat.completions.create(
                    model="deepseek-coder",
                    messages=[
                        {"role": "system", "content": sys_message},
                        {"role": "user", "content": prompt},
                    ],
                    response_format={"type": "json_object"},
                    temperature=0,
                    stream=False,

                )
            except Exception as e:
                print(e)
                continue
            try:
                json.loads(response.choices[0].message.content)
                flag = False
            except:
                flag = True
                num += 1

        return response.choices[0].message.content



