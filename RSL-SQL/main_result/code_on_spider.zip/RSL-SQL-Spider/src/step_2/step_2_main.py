from llm.thought_gpt import DeepSeek as thought_gpt
from llm.table_gpt import DeepSeek as table_gpt
from llm.word_gpt import DeepSeek as word_gpt
from llm.relation_gpt import DeepSeek as relation_gpt
import json
from tqdm import tqdm
from utils.util import simple_throw_row_data


def main(ppl_file, output_file,info_file):
    thought_gpt_model = thought_gpt()
    table_gpt_model = table_gpt()
    word_gpt_model = word_gpt()
    relation_gpt_model = relation_gpt()



    # 1.加载prompt信息 从0开始
    with open(ppl_file, 'r') as f:
        ppls = json.load(f)


    answers = []
    informations = []

    for i in tqdm(range(len(ppls))):
        information={}
        ppl = ppls[i]
        db = ppl['db']
        question = ppl['question'].strip()
        simple_ddl = ppl['simplified_ddl'].strip()
        ddl_data = ppl['ddl_data'].strip()
        foreign_key = ppl['foreign_key'].strip()

        example = ppl['example']
        tables = ppl['tables']
        columns = ppl['columns']


        # 简化ddl
        table_list = {}
        simple_ddl_simple = "#\n# "
        for table in tables:
            simple_ddl_simple += table + "("
            column_list = []
            for column in columns:
                _table = column.split(".")[0].strip()
                if _table == table:
                    column = column.split(".")[1].strip()
                    column_list.append(column)
                    simple_ddl_simple += column + ","
            table_list[table] = column_list
            simple_ddl_simple = simple_ddl_simple[:-1] + ")\n# "
        simple_ddl = simple_ddl_simple.strip()

        # 简化data
        data_ddl = simple_throw_row_data(db, tables, table_list)
        ddl_data = "#\n" + data_ddl.strip() + "\n# "

        # 简化foreign_key
        temp = "#\n"
        for line in foreign_key.split("\n"):
            try:
                table1 = line.split("# ")[1].split("(")[0].strip()
                table2 = line.split("references ")[1].split("(")[0].strip()
                if table1.lower() in tables and table2.lower() in tables:
                    temp += line + "\n"
            except:
                continue
        foreign_key = temp.strip() + "\n# "

        table_info = '### Sqlite SQL tables, with their properties:\n'
        table_info += simple_ddl + '\n' + '### Here are some data information about database references.\n' + ddl_data + '\n### Foreign key information of Sqlite SQL tables, used for table joins:\n' + foreign_key


        # 3.2. table_gpt
        table_gpt_res_prompt = table_info.strip() + '\n\n'  + "### Question: " + question
        table_gpt_res = table_gpt_model(table_gpt_res_prompt)
        table_gpt_res = json.loads(table_gpt_res)
        information['tables'] = table_gpt_res['tables']
        information['columns'] = table_gpt_res['columns']

        # 3.1. word_gpt

        word_gpt_res_prompt = table_info.strip() + '\n\n'  + "### Question: " + question
        word_gpt_res = word_gpt_model(word_gpt_res_prompt)

        word_gpt_res = json.loads(word_gpt_res)
        information['sql_keywords'] = word_gpt_res['sql_keywords']

        # 3.3. relation_gpt
        relation_gpt_res = relation_gpt_model(question)
        relation_gpt_res = json.loads(relation_gpt_res)
        information['conditions'] = relation_gpt_res['conditions']
        informations.append(information)

        table_info += f'\n### sql_keywords: {word_gpt_res["sql_keywords"]}\n'
        table_info += f'### tables: {table_gpt_res["tables"]}\n'
        table_info += f'### columns: {table_gpt_res["columns"]}\n'
        table_info += f'### conditions: {relation_gpt_res["conditions"]}'

        table_info = example.strip() + '\n\n' + "### Answer the question by sqlite SQL query only and with no explanation. You must minimize SQL execution time while ensuring correctness.\n" + table_info.strip() + '\n\n' + "### Question: " + question

        # 3.4. thought_gpt
        answer = thought_gpt_model(table_info)
        try:
            answer = json.loads(answer)
        except Exception as e:
            print(e)
            answer = answer.replace("\\", "\\\\")
            answer = json.loads(answer)
        answer = answer['sql'].replace('\n', ' ')
        answers.append(answer)

        with open(output_file, 'w', encoding='utf-8') as file:
            for sql in answers:
                file.write(str(sql) + '\n')
        with open(info_file, 'w', encoding='utf-8') as file:
            json.dump(informations, file, indent=4, ensure_ascii=False)



# main('information/ppl_dev.json',  'step_2_sql.txt','aug.json')





