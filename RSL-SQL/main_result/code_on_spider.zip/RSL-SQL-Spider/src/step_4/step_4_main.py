from llm.thought_gpt import DeepSeek
import json
from tqdm import tqdm
from utils.util import execute_sql, simple_throw_row_data, get_describe
import time
import threading


def main(ppl_file, sql_file, output_file):
    deepseek = DeepSeek()

    # 1.加载prompt信息 从0开始
    with open(ppl_file, 'r') as f:
        ppls = json.load(f)

    with open(sql_file, 'r') as f:
        pre_sqls = f.readlines()

    with open('llm/system_message_zn.txt', 'r') as f:
        sys_message = f.read()



    answers = []

    for i in tqdm(range(len(ppls))):
        message = []
        message.append({'role': 'system', 'content': sys_message})
        ppl = ppls[i]
        db = ppl['db']
        question = ppl['question'].strip()
        foreign_key = ppl['foreign_key'].strip()
        # evidence = ppl['evidence'].strip()
        tables = ppl['tables']
        columns = ppl['columns']
        simple_ddl = ppl['simplified_ddl'].strip()
        ddl_data = ppl['ddl_data'].strip()

        example = ppl['example']

        tables = ppl['tables']
        columns = ppl['columns']


        # 简化ddl
        table_list = {}
        simple_ddl_simple = "#\n# "
        for table in tables:
            simple_ddl_simple += table + "("
            column_list = []
            for column in columns:
                _table = column.split(".")[0].strip()
                if _table == table:
                    column = column.split(".")[1].strip()
                    column_list.append(column)
                    simple_ddl_simple += column + ","
            table_list[table] = column_list
            simple_ddl_simple = simple_ddl_simple[:-1] + ")\n# "
        simple_ddl = simple_ddl_simple.strip()

        # 简化data
        data_ddl = simple_throw_row_data(db, tables, table_list)
        ddl_data = "#\n" + data_ddl.strip() + "\n# "

        # 简化foreign_key
        temp = "#\n"
        for line in foreign_key.split("\n"):
            try:
                table1 = line.split("# ")[1].split("(")[0].strip()
                table2 = line.split("references ")[1].split("(")[0].strip()
                if table1.lower() in tables and table2.lower() in tables:
                    temp += line + "\n"
            except:
                continue
        foreign_key = temp.strip() + "\n# "


        table_info = '### Sqlite SQL tables, with their properties:\n'
        table_info += simple_ddl + '\n' + '### Here are some data information about database references.\n' + ddl_data + '\n### Foreign key information of Sqlite SQL tables, used for table joins:\n' + foreign_key  + "\n#\n"

        table_info += f'\n### sql_keywords: {ppl["sql_keywords"]}'
        table_info += f'\n### conditions: {ppl["conditions"]}'

        table_info = example.strip() + '\n\n' + "### Answer the question by sqlite SQL query only and with no explanation. You must minimize SQL execution time while ensuring correctness.\n" + table_info.strip() + '\n\n'  + "\n### Question: " + question + '\n\n'

        pre_sql = pre_sqls[i].strip()

        num = 0
        while num < 5:

            row_count, column_count, result = execute_sql(pre_sql, db)

            if num > 0:
                table_info = "### Buggy SQL: " + pre_sql.strip() + "\n" + f"### The result of the buggy SQL is [{result.strip()}]. Please fix the SQL to get the correct result."
            if row_count == 0 and column_count == 0 and "error" in result:
                message.append({'role': 'user', 'content': table_info})
                message, answer = deepseek(message)
                num += 1
                try:
                    answer = json.loads(answer)
                except Exception as e:
                    answer = answer.replace('\\', '\\\\')
                    try:
                        answer = json.loads(answer)
                    except Exception as e:
                        break
                pre_sql = answer['sql'].strip()
            else:
                break
        answers.append(pre_sql.replace('\n', ' '))
        with open(output_file, 'w') as f:
            for answer in answers:
                f.write(answer + '\n')

main('information/ppl_dev.json', '../step_3/gpt_pre_output.txt', 'final_sql.txt')

# extract_sql('output.json', 'output.sql')

