import os
import threading
# from generate_prompt_sl import generate_prompt
# from generate_prompt import generate_prompt
from step_4_main import main
from utils.util import split_json, merge_sqltxt, split_txt


def round():
    split_json('information/ppl_dev.json', 'split_ppl/ppl')
    split_txt('../step_3/step_3_sql.txt', 'split_sql/sql')

    ppl_files = ['ppl_file1.json', 'ppl_file2.json', 'ppl_file3.json', 'ppl_file4.json']
    sql_files = ['sql_file1.txt', 'sql_file2.txt', 'sql_file3.txt', 'sql_file4.txt']
    output_files = ['output_file1.txt', 'output_file2.txt', 'output_file3.txt', 'output_file4.txt']

    threads = []
    for i in range(4):
        t = threading.Thread(target=main(), args=(f'split_ppl/{ppl_files[i]}', f'split_sql/{sql_files[i]}', f'split_output/{output_files[i]}'))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print('All threads are done!')

    merge_sqltxt(output_files, 'final_sql.txt')
    print('All files are merged!')


round()
