from llm.table_gpt import DeepSeek as table_gpt
from llm.thought_gpt import DeepSeek as thought_gpt
import json
from tqdm import tqdm


def main(ppl_file, output_file,info_file):
    table_gpt_model = table_gpt()
    thought_gpt_model = thought_gpt()

    # 1.加载prompt信息 从0开始
    with open(ppl_file, 'r') as f:
        ppls = json.load(f)

    answers = []
    informations = []

    for i in tqdm(range(len(ppls))):
        information={}
        ppl = ppls[i]
        db = ppl['db']
        question = ppl['question'].strip()
        simple_ddl = ppl['simplified_ddl'].strip()
        # db_describe = ppl['table_describe'].strip()
        ddl_data = ppl['ddl_data'].strip()
        foreign_key = ppl['foreign_key'].strip()
        # evidence = ppl['evidence'].strip()

        example = ppl['example']

        table_info = '### Sqlite SQL tables, with their properties:\n'
        table_info += simple_ddl + '\n' + '### Here are some data information about database references.\n' + ddl_data + '\n### Foreign key information of Sqlite SQL tables, used for table joins:\n' + foreign_key

        # 3.2. table_gpt
        table_gpt_res_prompt = table_info.strip() + '\n\n'  + "### Question: " + question
        table_gpt_res = table_gpt_model(table_gpt_res_prompt)
        table_gpt_res = json.loads(table_gpt_res)
        information['tables'] = table_gpt_res['tables']
        information['columns'] = table_gpt_res['columns']

        informations.append(information)


        # We find that in spider dataset, the table_gpt_res['tables'] and table_gpt_res['columns'] are not useful.
        # table_info += f'\n### tables: {table_gpt_res["tables"]}\n'
        # table_info += f'### columns: {table_gpt_res["columns"]}\n'

        table_info = example.strip() + '\n\n' + "### Answer the question by sqlite SQL query only and with no explanation. You must minimize SQL execution time while ensuring correctness.\n" + table_info.strip() + '\n\n'  + "### Question: " + question

        # 3.4. thought_gpt
        answer = thought_gpt_model(table_info)
        try:
            answer = json.loads(answer)
        except Exception as e:
            print(e)
            answer = answer.replace("\\", "\\\\")
            answer = json.loads(answer)
        answer = answer['sql'].replace('\n', ' ')
        answers.append(answer)

        with open(output_file, 'w', encoding='utf-8') as file:
            for sql in answers:
                file.write(str(sql) + '\n')
        with open(info_file, 'w', encoding='utf-8') as file:
            json.dump(informations, file, indent=4, ensure_ascii=False)



# main('information/ppl_dev.json',  'step_1_sql.txt','LLM.json')





