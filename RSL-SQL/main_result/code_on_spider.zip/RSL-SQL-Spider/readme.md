
This Prompt file is that I constructed by refering to the paper PET-SQL.
This method used to construct few-shot examples is very interesting.



- data_construct + extract_example.py
- step_1
- schema_linking
- step_2
- step_3
- step_4
