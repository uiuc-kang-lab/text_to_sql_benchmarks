import json

with open('prompt.json', 'r') as f:
    prompt = json.load(f)

answer = []

for x in prompt:
    x = x.split('### Answer the question by sqlite SQL query only and with no explanation. You must minimize SQL execution time while ensuring correctness.')[0].strip()
    answer.append(x)

with open('src/step_1/example.json', 'w') as f:
    json.dump(answer, f, indent=4, ensure_ascii=False)